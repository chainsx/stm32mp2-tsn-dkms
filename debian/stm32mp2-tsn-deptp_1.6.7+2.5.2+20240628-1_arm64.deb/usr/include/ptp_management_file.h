/******************************************************************************
* TTTech Flexibilis, flx_ptp_tool
* Copyright(c) 2018 TTTech Flexibilis Oy. 
* 
* ALL RIGHTS RESERVED. 
* Usage of this software, including source code, binaries, documentation, 
* is subject to restrictions and conditions of the applicable license 
* agreement with TTTech Computertechnik AG or its affiliates.    
* 
* All trademarks used are the property of their respective owners. 
* 
* TTTech Computertechnik AG or its affiliates does not assume any liability 
* arising out of the application or use of any product described or shown 
* herein. TTTech Computertechnik AG or its affiliates reserves the right
* to make changes, at any time, in order to improve reliability, function 
* or design. 
* 
* Contact: tttech.com * support@tttech.com 
* TTTech Computertechnik AG, Schoenbrunnerstrasse 7, 1040 Vienna, Austria 
******************************************************************************/
/// @file

#ifndef PTP_MANAGEMENT_FILE_H
#define PTP_MANAGEMENT_FILE_H

#include "ptp_management_client.h"

/**
 * @defgroup management-transport-file PTP management over device file
 *
 * PTP management transport API for communication over device file
 *
 * @{
 */

/**
 * Options for PTP management over file (device) interface.
 */
struct ptp_management_file_opt {
    const char *filename;       ///< device filename
    const char *destination;    ///< destination MAC address to use
    unsigned int timeout_ms;    ///< timeout in milliseconds
};

/**
 * Open communication for PTP management over file (device) interface.
 * @param ctx Management context.
 * @param opt Options for communication.
 */
int ptp_management_connect_file(struct ptp_management_ctx *ctx,
                                const struct ptp_management_file_opt *opt);

/** @} */

#endif
