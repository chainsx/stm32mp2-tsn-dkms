/******************************************************************************
* TTTech Flexibilis, flx_ptp_tool
* Copyright(c) 2018 TTTech Flexibilis Oy.
*
* ALL RIGHTS RESERVED.
* Usage of this software, including source code, binaries, documentation,
* is subject to restrictions and conditions of the applicable license
* agreement with TTTech Computertechnik AG or its affiliates.
*
* All trademarks used are the property of their respective owners.
*
* TTTech Computertechnik AG or its affiliates does not assume any liability
* arising out of the application or use of any product described or shown
* herein. TTTech Computertechnik AG or its affiliates reserves the right
* to make changes, at any time, in order to improve reliability, function
* or design.
*
* Contact: tttech.com * support@tttech.com
* TTTech Computertechnik AG, Schoenbrunnerstrasse 7, 1040 Vienna, Austria
******************************************************************************/
/**
 * @file
 * @brief This file contains PTP runtime control library API.
*/


#ifndef PTP_MANAGEMENT_CLIENT_H
#define PTP_MANAGEMENT_CLIENT_H

#include <stdint.h>
#include <stdbool.h>
#include <inttypes.h>
#include <arpa/inet.h>
#include <sys/select.h>

#include <ptp_dataset.h>


/**
 * @defgroup management PTP Management client API
 *
 * Library API for PTP local management
 *
 * @{
 *
 * PTP management client API provides means for getting and setting
 * PTP stack properties at runtime. Different means for communicating
 * with the PTP stack are provided by different transport implementations.
 *
 * Steps for usage are:
 * - initialize management client by calling ptp_management_init()
 * - connect transport to management client with desired transport
 *   specific parameters using ptp_management_connect_xxx()
 * - interact with the stack:
 *      - call one of the ptp_management_send_xxx() functions
 *      - wait when result is available using select or poll (optional),
 *        see ptp_management_get_fd() and ptp_management_set_fds()
 *      - call one of the ptp_management_recv_xxx() functions to obtain result
 * - close transport interface to PTP stack by calling ptp_management_close()
 * - release all management resources by calling ptp_management_free()
 *
 * Example: init
 *
 * @code
 * struct ptp_management_ctx *ctx;
 * struct ptp_management_local_opt local_opt;
 *
 * ctx = ptp_management_init();
 * ret = ptp_management_connect_local(ctx, &local_opt);
 * @endcode
 *
 * Example: cleanup
 *
 * @code
 * ptp_management_close(ctx);
 * ptp_management_free(ctx);
 * @endcode
 *
 * Example: define variables for sending and receiving
 *
 * @code
 * struct CurrentDataSet cds;
 * uint8_t domain;
 * struct PortIdentity target_port_id;
 * struct PortIdentity source_port_id;
 * fd_set rfds;
 * int nfds;
 * int ret;
 * @endcode
 *
 * Example: send request to get current dataset
 *
 * @code
 * ret = ptp_management_send_get(ctx, domain, &target_port_id,
 *                               PTP_MANAGEMENT_DATA_CURRENT_DATASET);
 * @endcode
 *
 * Example: receive current dataset
 *
 * @code
 * FD_ZERO(&rfds);
 * nfds = ptp_management_set_fds(ctx, &rfds);
 * ret = select(nfds, &rfds, NULL, NULL, NULL);
 *
 * ret = ptp_management_recv_current_dataset(ctx, &source_port_id, &cds);
 * if (ret) {
 *     // nothing / receive error / not current dataset (e.g. error) / garbage
 * }
 * @endcode
 *
 * Example: receive result to ptp_management_send_set_xxx() (ack/error)
 *
 * @code
 * FD_ZERO(&rfds);
 * nfds = ptp_management_set_fds(&rfds);
 * ret = select(nfds, &rfs, NULL, NULL, NULL);
 *
 * ret = ptp_management_recv_ack(ctx, &source_port_id);
 * if (ret) {
 *     // nothing / receive error / error information / garbage
 * }
 * @endcode
 */

/// Convert uint64_t from network to host byte order
static inline uint64_t ntohll(uint64_t x)
{
    uint64_t ret;
    // Test for endianness to decide whether to swap
    if (ntohs(0xaa55u) == 0xaa55u) {
        // Big-endian
        ret = x;
    } else {
        // Little-endian
                ret =
                    ((x & 0x00000000000000ffull) << 56) |
                    ((x & 0x000000000000ff00ull) << 40) |
                    ((x & 0x0000000000ff0000ull) << 24) |
                    ((x & 0x00000000ff000000ull) << 8) |
                    ((x & 0x000000ff00000000ull) >> 8) |
                    ((x & 0x0000ff0000000000ull) >> 24) |
                    ((x & 0x00ff000000000000ull) >> 40) |
                    ((x & 0xff00000000000000ull) >> 56);
    }
    return ret;
}
/// Convert uint64_t from host to network byte order
#define htonll(x) ntohll(x)

#define SEC_IN_NS 1000000000

#define PRIm8 "%02" PRIx8

/// printf style format string for MAC address
#define PRImac PRIm8 ":" PRIm8 ":" PRIm8 ":" PRIm8 ":" PRIm8 ":" PRIm8

/// printf style format string for PTP clock identity
#define PRIclk PRIm8 ":" PRIm8 ":" PRIm8 ":" PRIm8 ":" PRIm8 ":" PRIm8 ":" PRIm8 ":" PRIm8

#define SCNm8 "%02" SCNx8

/// scanf style format string for MAC address
#define SCNmac SCNm8 ":" SCNm8 ":" SCNm8 ":" SCNm8 ":" SCNm8 ":" SCNm8

/// scanf style format string for PTP clock identity
#define SCNclk SCNm8 ":" SCNm8 ":" SCNm8 ":" SCNm8 ":" SCNm8 ":" SCNm8 ":" SCNm8 ":" SCNm8

struct ptp_management_ctx;

/**
 * Data type names for data carried by get requests.
 */
enum ptp_management_data_type {
    PTP_MANAGEMENT_DATA_CURRENT_DATASET,            ///< Current dataset
    PTP_MANAGEMENT_DATA_DEFAULT_DATASET,            ///< Default dataset
    PTP_MANAGEMENT_DATA_PARENT_DATASET,             ///< Parent dataset
    PTP_MANAGEMENT_DATA_PORT_DATASET,               ///< Port dataset
    PTP_MANAGEMENT_DATA_TC_PORT_DATASET,            ///< TC port dataset
    PTP_MANAGEMENT_DATA_TIME_PROPERTIES_DATASET,    ///< Time properties dataset
    PTP_MANAGEMENT_DATA_TIME,                       ///< Time data
};

/**
 * Allocate and initialize PTP management context.
 * @return Opaque management context.
 */
struct ptp_management_ctx *ptp_management_init(void);

/**
 * Get file descriptor for select/poll/etc.
 * @param ctx Management context.
 * @return File descriptor or negative.
 */
int ptp_management_get_fd(struct ptp_management_ctx *ctx);

/**
 * Set file descriptor set for select.
 * @param ctx Management context.
 * @param fds File descriptor set to update.
 * @return nfds value for select.
 */
int ptp_management_set_fds(struct ptp_management_ctx *ctx, fd_set *fds);

/**
 * Close management communication.
 * @param ctx Management context.
 */
void ptp_management_close(struct ptp_management_ctx *ctx);

/**
 * Release management context.
 * @param ctx Management context.
 */
void ptp_management_free(struct ptp_management_ctx *ctx);

// Functions to send requests

/**
 * Send get request.
 * @param ctx Management context.
 * @param domain Target domain number.
 * @param target_port_id Target port identity. Clock identity part can be
 * clock_id_all.
 * @param type Data to get.
 */
int ptp_management_send_get(
        struct ptp_management_ctx *ctx,
        uint8_t domain, const struct PortIdentity *target_port_id,
        enum ptp_management_data_type type);

/**
 * Send set time request.
 * @param ctx Management context.
 * @param domain Target domain number.
 * @param target_port_id Target port identity. Clock identity part can be
 * clock_id_all.
 * @param timestamp New time.
 */
int ptp_management_send_set_time(
        struct ptp_management_ctx *ctx,
        uint8_t domain, const struct PortIdentity *target_port_id,
        const struct Timestamp *timestamp);

/**
 * Send set priority1 request.
 * @param ctx Management context.
 * @param domain Target domain number.
 * @param target_port_id Target port identity. Clock identity part can be
 * clock_id_all.
 * @param priority New priority1 value.
 */
int ptp_management_send_set_priority1(
        struct ptp_management_ctx *ctx,
        uint8_t domain, const struct PortIdentity *target_port_id,
        uint8_t priority);

/**
 * Send set set priority2 request.
 * @param ctx Management context.
 * @param domain Target domain number.
 * @param target_port_id Target port identity. Clock identity part can be
 * clock_id_all.
 * @param priority New priority2 value.
 */
int ptp_management_send_set_priority2(
        struct ptp_management_ctx *ctx,
        uint8_t domain, const struct PortIdentity *target_port_id,
        uint8_t priority);

/**
 * Send set domain request.
 * @param ctx Management context.
 * @param domain Target domain number.
 * @param target_port_id Target port identity. Clock identity part can be
 * clock_id_all.
 * @param new_domain New domain value.
 */
int ptp_management_send_set_domain(
        struct ptp_management_ctx *ctx,
        uint8_t domain, const struct PortIdentity *target_port_id,
        uint8_t new_domain);

/**
 * Send set UTC properties request.
 * @param ctx Management context.
 * @param domain Target domain number.
 * @param target_port_id Target port identity. Clock identity part can be
 * clock_id_all.
 * @param utc New UTC properties.
 */
int ptp_management_send_set_utc_properties(
        struct ptp_management_ctx *ctx,
        uint8_t domain, const struct PortIdentity *target_port_id,
        const struct UTCProperties *utc);

/**
 * Send set clock accuracy request.
 * @param ctx Management context.
 * @param domain Target domain number.
 * @param target_port_id Target port identity. Clock identity part can be
 * clock_id_all.
 * @param clock_accuracy New clock accuracy.
 */
int ptp_management_send_set_clock_accuracy(
        struct ptp_management_ctx *ctx,
        uint8_t domain, const struct PortIdentity *target_port_id,
        ClockAccuracy clock_accuracy);

/**
 * Send set clock class request.
 * @param ctx Management context.
 * @param domain Target domain number.
 * @param target_port_id Target port identity. Clock identity part can be
 * clock_id_all.
 * @param clock_class New clock accuracy.
 */
int ptp_management_send_set_clock_class(
        struct ptp_management_ctx *ctx,
        uint8_t domain, const struct PortIdentity *target_port_id,
        uint8_t clock_class);


/**
 * Send set port state request.
 * @param ctx Management context.
 * @param domain Target domain number.
 * @param target_port_id Target port identity. Clock identity part can be
 * clock_id_all.
 * @param enabled True to enable or false to disable port.
 */
int ptp_management_send_set_port_state(
        struct ptp_management_ctx *ctx,
        uint8_t domain, const struct PortIdentity *target_port_id,
        bool enabled);

// Functions to receive responses

/**
 * Receive current dataset.
 * @param ctx Management context.
 * @param source_port_id Source port identity.
 * @param ds Pointer to dataset to write according to received information.
 */
int ptp_management_recv_current_dataset(
        struct ptp_management_ctx *ctx,
        struct PortIdentity *source_port_id,
        struct CurrentDataSet *ds);

/**
 * Receive default dataset.
 * @param ctx Management context.
 * @param source_port_id Source port identity.
 * @param ds Pointer to dataset to write according to received information.
 */
int ptp_management_recv_default_dataset(
        struct ptp_management_ctx *ctx,
        struct PortIdentity *source_port_id,
        struct DefaultDataSet *ds);

/**
 * Receive parent dataset.
 * @param ctx Management context.
 * @param source_port_id Source port identity.
 * @param ds Pointer to dataset to write according to received information.
 */
int ptp_management_recv_parent_dataset(
        struct ptp_management_ctx *ctx,
        struct PortIdentity *source_port_id,
        struct ParentDataSet *ds);

/**
 * Receive port dataset.
 * @param ctx Management context.
 * @param source_port_id Source port identity.
 * @param ds Pointer to dataset to write according to received information.
 * Field g must be set to non-NULL on input to get port global dataset.
 */
int ptp_management_recv_port_dataset(
        struct ptp_management_ctx *ctx,
        struct PortIdentity *source_port_id,
        struct PortDataSet *ds);

/**
 * Receive transparent clock port dataset.
 * @param ctx Management context.
 * @param source_port_id Source port identity.
 * @param ds Pointer to dataset to write according to received information.
 * Field g must be set to non-NULL on input to get port global dataset.
 */
int ptp_management_recv_tc_port_dataset(
        struct ptp_management_ctx *ctx,
        struct PortIdentity *source_port_id,
        struct TransparentClockPortDataSet *ds);

/**
 * Receive time properties dataset.
 * @param ctx Management context.
 * @param source_port_id Source port identity.
 * @param ds Pointer to dataset to write according to received information.
 */
int ptp_management_recv_time_properties_dataset(
        struct ptp_management_ctx *ctx,
        struct PortIdentity *source_port_id,
        struct TimeProperitiesDataSet *ds);

/**
 * Receive current time.
 * @param ctx Management context.
 * @param source_port_id Source port identity.
 * @param ds Pointer to timestamp to write according to received information.
 */
int ptp_management_recv_time(
        struct ptp_management_ctx *ctx,
        struct PortIdentity *source_port_id,
        struct Timestamp *timestamp);

/**
 * Receive acknowledgement to set request.
 * @param ctx Management context.
 * @param source_port_id Source port identity.
 */
int ptp_management_recv_ack(
        struct ptp_management_ctx *ctx,
        struct PortIdentity *source_port_id);

/** @} */

#endif
