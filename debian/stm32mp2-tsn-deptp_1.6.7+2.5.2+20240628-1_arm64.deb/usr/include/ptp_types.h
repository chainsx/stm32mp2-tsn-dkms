/******************************************************************************
* TTTech Flexibilis, xr7ptp
* Copyright(c) 2018 TTTech Flexibilis Oy. 
* 
* ALL RIGHTS RESERVED. 
* Usage of this software, including source code, binaries, documentation, 
* is subject to restrictions and conditions of the applicable license 
* agreement with TTTech Computertechnik AG or its affiliates.    
* 
* All trademarks used are the property of their respective owners. 
* 
* TTTech Computertechnik AG or its affiliates does not assume any liability 
* arising out of the application or use of any product described or shown 
* herein. TTTech Computertechnik AG or its affiliates reserves the right
* to make changes, at any time, in order to improve reliability, function 
* or design. 
* 
* Contact: tttech.com * support@tttech.com 
* TTTech Computertechnik AG, Schoenbrunnerstrasse 7, 1040 Vienna, Austria 
******************************************************************************/
#ifndef _PTP_TYPES_H_
#define _PTP_TYPES_H_

#include <arpa/inet.h>

#include <stdint.h>
#include <stdbool.h>
#include <inttypes.h>
#include <stdlib.h>
#include <limits.h>
#include <string.h>

/// Return minimum value of two values
#define MIN(a,b) ((a)<(b)?(a):(b))

/// Convert from ns16 presentation to nanoseconds (drop 16 lowest bits)
#define CONVERT_NS16_TO_NS(value) ((value)/65536)

#endif                          // _PTP_TYPES_H_
