/******************************************************************************
* TTTech Flexibilis, xr7ptp
* Copyright(c) 2018 TTTech Flexibilis Oy.
*
* ALL RIGHTS RESERVED.
* Usage of this software, including source code, binaries, documentation,
* is subject to restrictions and conditions of the applicable license
* agreement with TTTech Computertechnik AG or its affiliates.
*
* All trademarks used are the property of their respective owners.
*
* TTTech Computertechnik AG or its affiliates does not assume any liability
* arising out of the application or use of any product described or shown
* herein. TTTech Computertechnik AG or its affiliates reserves the right
* to make changes, at any time, in order to improve reliability, function
* or design.
*
* Contact: tttech.com * support@tttech.com
* TTTech Computertechnik AG, Schoenbrunnerstrasse 7, 1040 Vienna, Austria
******************************************************************************/
/**
 * @file
 * @brief This file contains generic PTP datatypes.
*/

#ifndef _PTP_DATASET_H_
#define _PTP_DATASET_H_
#include <stdio.h>
#include <string.h>

#include <ptp_types.h>

/**
 * @defgroup ptp_dataset PTP Dataset Definitions
 *
 * PTP Dataset Definitions.
 *
 * @{
 */

/// Error codes.
#define PTP_ERR_OK              0       ///< No error
#define PTP_ERR_GEN             -1      ///< General error
#define PTP_ERR_FRAME           -2      ///< Frame error
#define PTP_ERR_TIMEOUT         -3      ///< Timeout error
#define PTP_ERR_NET             -4      ///< Error from network interface
#define PTP_ERR_REJECTED        -5      ///< Management operation rejected

/**
* PTP protocol state machine states.
*/
enum PortState {
    PORT_INITIALIZING = 1,
    PORT_FAULTY = 2,
    PORT_DISABLED = 3,
    PORT_LISTENING = 4,
    PORT_PRE_MASTER = 5,
    PORT_MASTER = 6,
    PORT_PASSIVE = 7,
    PORT_UNCALIBRATED = 8,
    PORT_SLAVE = 9,
};

/**
* PTP protocol TC port state.
*/
enum TCPortState {
    TC_PORT_ENABLED,
    TC_PORT_DISABLED,
};

/// PTP types.
/**
* The TimeInterval type represents time intervals.
*/
struct TimeInterval {
    int64_t scaled_nanoseconds; ///< nanoseconds multiplied by 2^16.
};
#define TIMEINTERVAL_UNDEFINED INT64_MAX

/**
* The Timestamp type represents a positive time with respect to the epoch.
*/
struct Timestamp {
    int64_t seconds;            ///< portion of the timestamp in units of seconds.
    uint32_t nanoseconds;       ///< nanoseconds portion of the timestamp (<10^9).
    uint16_t frac_nanoseconds;  ///< fractional nanoseconds part
};

/**
* The ClockIdentity type that identifies a PTP clock.
*/
typedef uint8_t ClockIdentity[8];
extern const ClockIdentity clock_id_all;        // all 1's

/**
* The PortIdentity type identifies a PTP port.
*/
struct PortIdentity {
    ClockIdentity clock_identity;       ///< PTP clock identity
    uint16_t port_number;       ///< PTP port
} __attribute__ ((packed));

typedef uint8_t ClockAccuracy;  /// type used to store enum ClockAccuracy_enum
/**
* Clock accuracy enumeration.
*/
enum ClockAccuracy_enum {
    CLOCK_25NS = 0x20,          ///< The time is accurate to within 25 ns
    CLOCK_100NS = 0x21,         ///< The time is accurate to within 100 ns
    CLOCK_250NS = 0x22,         ///< The time is accurate to within 250 ns
    CLOCK_1US = 0x23,           ///< The time is accurate to within 1 us
    CLOCK_2_5US = 0x24,         ///< The time is accurate to within 2.5 us
    CLOCK_10US = 0x25,          ///< The time is accurate to within 10 us
    CLOCK_25US = 0x26,          ///< The time is accurate to within 25 us
    CLOCK_100US = 0x27,         ///< The time is accurate to within 100 us
    CLOCK_250US = 0x28,         ///< The time is accurate to within 250 us
    CLOCK_1MS = 0x29,           ///< The time is accurate to within 1 ms
    CLOCK_2_5MS = 0x2A,         ///< The time is accurate to within 2.5 ms
    CLOCK_10MS = 0x2B,          ///< The time is accurate to within 10 ms
    CLOCK_25MS = 0x2C,          ///< The time is accurate to within 25 ms
    CLOCK_100MS = 0x2D,         ///< The time is accurate to within 100 ms
    CLOCK_250MS = 0x2E,         ///< The time is accurate to within 250 ms
    CLOCK_1S = 0x2F,            ///< The time is accurate to within 1 s
    CLOCK_10S = 0x30,           ///< The time is accurate to within 10 s
    CLOCK_OVER10S = 0x31,       ///< The time is accurate to >10 s
    // 0x80-0xFD For use by alternate PTP profiles
};

/**
* The ClockQuality represents the quality of a clock.
*/
struct ClockQuality {
    uint8_t clock_class;        ///< Clock class
    ClockAccuracy clock_accuracy;       ///< clock accuracy
    uint16_t offset_scaled_log_variance;        ///< offset
} __attribute__ ((packed));

#define PTP_TEXT_MAX_SIZE 200
/**
* The PTPText data type is used to represent textual material in PTP messages.
* The text field shall be encoded as UTF-8 symbols as specified by
* ISO/IEC 10646.
* The most significant octet of the leading text symbol shall be
* the element of the array with index 0.
*/
struct PTPText {
    uint8_t length;
    uint8_t text[PTP_TEXT_MAX_SIZE];
};

/**
* Time source enumeration.
*/
enum TimeSource {
    TS_ATOMIC_CLOCK = 0x10,     ///< Any device, or device directly connected to atomic clock
    TS_GPS = 0x20,              ///< Any device synchronized to any of the satellite systems
    TS_TERRESTRIAL_RADIO = 0x30,        ///< Any device synchronized via any of the radio distribution systems
    TS_PTP = 0x40,              ///< PTP Any device synchronized to a PTP based source
    TS_NTP = 0x50,              ///< Any device synchronized via NTP to servers
    TS_HAND_SET = 0x60,         ///< Used in all cases for any device whose time has been set human interface based on observation
    TS_OTHER = 0x90,            ///< Other source of time and/or frequency not covered by other values
    TS_INTERNAL_OSCILLATOR = 0xA0,      ///< Any device whose time is based on a free-running non-calibrated oscillator
};

/**
* Delay mechanism enumeration.
*/
enum DelayMechanism {
    DELAY_E2E = 0x01,           ///< The port is configured to use the delay request-response mechanism.
    DELAY_P2P = 0x02,           ///< The port is configured to use the peer delay mechanism.
    DELAY_COMMON_P2P = 0x03,    ///< The port is configured to use the common peer delay mechanism
    DELAY_DISABLED = 0xFE,      ///< The port does not implement the delay mechanism.
};

/// PTP domains
#define DEFAULT_DOMAIN      0   ///< Default domain
#define ALTERNATE_DOMAIN1   1   ///< Alternate domain 1
#define ALTERNATE_DOMAIN2   2   ///< Alternate domain 2
#define ALTERNATE_DOMAIN3   3   ///< Alternate domain 3
// 4-127 User defined Domains

#define ALTERNATE_TIME_OFFSET_DISPLAY_NAME_MAX_SIZE 10  // defined in standard
/**
 * Alternate time offset config.
 */
struct AlternateTimeOffsetConfig {
    bool enable;                ///< enable flag
    int32_t current_offset;     ///< currentOffset
    int32_t jump_seconds;       ///< jumpSeconds
    uint64_t time_of_next_jump; ///< timeOfNextJump
    char display_name[ALTERNATE_TIME_OFFSET_DISPLAY_NAME_MAX_SIZE];     ///< displayName
};

/**
 * IEEE_C37_238_TLV data.
 */
struct ieee_C37_238_TLV_config {
    uint8_t grandmaster_id[2];  ///< grandmasterID
    union {
        uint32_t grandmaster_time_inaccuracy;   ///< grandmasterTimeInaccuracy
        uint32_t local_time_inaccuracy; ///< LocTimeInacc
    };
    uint32_t network_time_inaccuracy;   ///< networkTimeInaccuracy
};

/// Datasets.
/**
* Default dataset.
*/
struct DefaultDataSet {
    bool two_step_clock;        ///< TRUE for two_step clock
    ClockIdentity clock_identity;       ///< Local clock identity
    uint32_t num_ports;         ///< number of ports, 1 for Ordinary clock
    struct ClockQuality clock_quality;  ///< quality of the clock
    uint8_t priority1;          ///< Priority1
    uint8_t priority2;          ///< Priority2
    uint8_t domain;             ///< PTP domain
    bool slave_only;            ///< true if only slave
    uint16_t sdo_id;            ///< sdoId (IEEE1588-2019)
#ifdef SUPPORT_IEEE_C37_238_TLV
    // IEEE_C37_238 TLV data sent while operating as master
    struct ieee_C37_238_TLV_config ieee_C37_238_config;
#endif
};

// Priority1 for non Grandmaster-capable instance
#define GPTP_PRIORITY1_NON_GM_CAPABLE 255

/**
* Current dataset.
*/
struct CurrentDataSet {
    uint32_t steps_removed;     ///< The number of communication paths traversed between the local clock and the grandmaster
    struct TimeInterval offset_from_master;     ///< The time difference between a master and a slave as computed by the slave
    struct TimeInterval mean_path_delay;        ///< The mean propagation time between a master and slave as computed by the slave
#ifdef SUPPORT_IEEE_C37_238_TLV
    uint32_t local_time_inaccuracy;     ///< LocTimeInacc
#endif
};

/**
* Parent dataset.
*/
struct ParentDataSet {
    struct PortIdentity parent_port_identity;   ///< The master port that issues the Sync messages used in synchronizing this clock
    bool parent_stats;          ///< TRUE if the clock has a port in the SLAVE state and observed_parent_offset_scaled_log_variance and observed_parent_clock_phase_change_rate are valid.
    uint16_t observed_parent_offset_scaled_log_variance;        ///<
    int32_t observed_parent_clock_phase_change_rate;    ///<
    ClockIdentity grandmaster_identity; ///< Grandmaster identity
    struct ClockQuality grandmaster_clock_quality;      ///< Grandmasterc clock quality
    uint8_t grandmaster_priority1;      ///< Grandmaster priority1
    uint8_t grandmaster_priority2;      ///< Grandmaster priority2
#ifdef SUPPORT_IEEE_C37_238_TLV
    // IEEE_C37_238 TLV data received from network
    struct ieee_C37_238_TLV_config ieee_C37_238_config;
#endif
};

/**
* Time properities dataset.
*/
struct TimeProperitiesDataSet {
    uint16_t current_utc_offset;        ///< The offset between TAI and UTC
    bool current_utc_offset_valid;      ///< TRUE if current_utc_offset is valid
    bool leap_59;               ///< TRUE if the last minute of the current UTC day will contain 59 seconds.
    bool leap_61;               ///< TRUE if the last minute of the current UTC day will contain 61 seconds.
    bool time_traceable;        ///< TRUE if the timescale and the value of current_utc_offset are traceable to a primary standard.
    bool frequency_traceable;   ///< TRUE if the frequency determining the timescale is traceable to a primary standard.
    bool ptp_timescale;         ///< TRUE if the clock timescale of the grandmaster clock is PTP.
    enum TimeSource time_source;        ///< The source of time used by the grandmaster clock.
#if NUM_SUPPORTED_ALTERNATE_TIME_CONFIGS
    ///< Alternate time offsets - may be zero
    struct AlternateTimeOffsetConfig
     alternate_time_offset[NUM_SUPPORTED_ALTERNATE_TIME_CONFIGS];
#endif
};

/**
* UTC properities.
*/
struct UTCProperties {
    uint16_t current_utc_offset;        ///< The offset between TAI and UTC
    bool current_utc_offset_valid;      ///< TRUE if current_utc_offset is valid
    bool leap_59;                       ///< TRUE if the last minute of the current UTC day will contain 59 seconds.
    bool leap_61;                       ///< TRUE if the last minute of the current UTC day will contain 61 seconds.
};

/**
* Port (global) dataset.
*/
struct PortGDataSet {
    uint32_t refcnt;            ///< reference counting object
    uint8_t version_number;     ///< PTP version used in port
    enum DelayMechanism delay_mechanism;        ///< The propagation delay measuring option used by the port in computing mean_path_delay.

    int8_t log_min_pdelay_req_interval; ///< Pdelay_Req interval.
    struct TimeInterval peer_mean_path_delay;   ///< an estimate of the current one-way propagation delay on the link attached to this port computed using the peer delay mechanism.
};

/**
* Port dataset gPTP.
*/
struct PortGptpDataSet {
    bool as_capable;
    int8_t log_gptp_capable_message_interval;
    uint8_t gptp_capable_receipt_timeout;
    bool neighbor_gptp_capable;
};

/**
* Port per instance dataset.
*/
struct PortDataSet {
    struct PortIdentity port_identity;  ///< Port identity of the port.
    struct PortGDataSet *g;     ///< ptr to global port data (one per physical/logical port)
    enum PortState port_state;  ///< Current port state.

    int8_t log_announce_interval;       ///< Announce interval.
    int8_t log_sync_interval;   ///< Sync interval for multicast messages.
    int8_t log_min_delay_req_interval;  ///< The minimum mean Delay_Req interval.
    uint8_t announce_receipt_timeout;   ///< An integral multiple of Announce intervals.

    struct PortGptpDataSet gptp;
};

/**
* Transparent clock default dataset.
*/
struct TransparentClockDefaultDataSet {
    ClockIdentity clock_identity;       ///< Local clock identity
    uint32_t num_ports;         ///< number of ports
    uint8_t domain;             ///< PTP domain
};

/**
* Transparent clock port dataset.
*/
struct TransparentClockPortDataSet {
    struct PortIdentity port_identity;  ///< Port identity of the port.
    struct PortGDataSet *g;     ///< ptr to global port data (one per physical/logical port)
    enum TCPortState tc_port_state;     ///< TC port state (enabled/disabled)

    /** TRUE if the port is faulty and FALSE if the port is operating normally.
     * The initialization value shall be FALSE. */
    bool faulty_flag;
};

/**
 * 1AS follow_up TLV data.
 */
struct gptp_data {
    double rate_ratio;
    uint16_t gm_time_base_indicator;
    struct Timestamp last_gm_phase_change;
    double last_gm_freq_change;
};

/** @} */

#endif                          // _PTP_DATASET_H_
